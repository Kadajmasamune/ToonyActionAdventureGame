using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Interface for weapons that participate in combat hit detection.
/// Allows CombatStateMachine to control hitbox state and query targets.
/// </summary>
public interface IWeapon
{
    /// <summary>Enable the weapon hitbox for hit detection.</summary>
    void EnableHitbox();

    /// <summary>Disable the weapon hitbox.</summary>
    void DisableHitbox();

    /// <summary>Read-only list of currently overlapping target colliders.</summary>
    IReadOnlyList<Collider> Targets { get; }

    /// <summary>Clear the list of overlapping targets.</summary>
    void ClearTargets();
}
