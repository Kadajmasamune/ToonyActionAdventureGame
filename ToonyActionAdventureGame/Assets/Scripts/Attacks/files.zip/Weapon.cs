using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Weapon implementation handling hitbox enabling/disabling and target detection.
/// Implements IWeapon to communicate with CombatStateMachine.
/// </summary>
public class Weapon : MonoBehaviour, IWeapon
{
    [SerializeField] private Collider weaponCollider;
    private WeaponHitbox hitbox;
    private CombatStateMachine combatStateMachine;

    public IReadOnlyList<Collider> Targets => hitbox.Targets;

    private void Awake()
    {
        ValidateReferences();
        InitializeReferences();
    }

    private void ValidateReferences()
    {
        if (weaponCollider == null)
        {
            weaponCollider = GetComponentInChildren<Collider>();
            if (weaponCollider == null)
                Debug.LogError($"No Collider found on Weapon or children on {gameObject.name}");
        }
    }

    private void InitializeReferences()
    {
        hitbox = GetComponentInChildren<WeaponHitbox>();
        if (hitbox == null)
            Debug.LogError($"No WeaponHitbox found on children of {gameObject.name}");

        combatStateMachine = GetComponentInParent<CombatStateMachine>();
        if (combatStateMachine == null)
            Debug.LogError($"No CombatStateMachine found in parent of {gameObject.name}");
        else
            combatStateMachine.Initialize(this);

        DisableHitbox();
    }

    public void EnableHitbox()
    {
        if (weaponCollider != null)
            weaponCollider.enabled = true;
    }

    public void DisableHitbox()
    {
        if (weaponCollider != null)
            weaponCollider.enabled = false;
    }

    public void ClearTargets()
    {
        if (hitbox != null)
            hitbox.Clear();
    }
}
