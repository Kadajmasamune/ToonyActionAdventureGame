using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Hitbox trigger for detecting enemy collision during attacks.
/// Maintains a list of currently overlapping enemy colliders.
/// </summary>
public class WeaponHitbox : MonoBehaviour
{
    [SerializeField] private LayerMask enemyLayer;
    private readonly List<Collider> targets = new();

    public IReadOnlyList<Collider> Targets => targets;

    private void OnTriggerEnter(Collider other)
    {
        if (!IsEnemyLayer(other))
            return;

        if (!targets.Contains(other))
            targets.Add(other);
    }

    private void OnTriggerExit(Collider other)
    {
        targets.Remove(other);
    }

    private bool IsEnemyLayer(Collider other)
    {
        return (enemyLayer.value & (1 << other.gameObject.layer)) != 0;
    }

    public void Clear()
    {
        targets.Clear();
    }
}
