using EntityStateMachines;
using System;
using UnityEngine;

/// <summary>
/// Player controller managing movement state machine, combat integration, and context.
/// Provides Attack.Context to CombatStateMachine for context-aware attack selection.
/// </summary>
[RequireComponent(typeof(AnimatorController))]
[RequireComponent(typeof(CombatStateMachine))]
public class Player : MonoBehaviour, ICombatHandler
{
    [Header("Movement")]
    [SerializeField] private float walkSpeed = 2.2f;
    [SerializeField] private float sprintSpeed = 4.8f;
    [SerializeField] private float strafingSpeed = 5f;
    [SerializeField] private float acceleration = 50f;
    [SerializeField] private float airControl = 0.5f;

    [Header("Jump")]
    [SerializeField] private float jumpForce = 4f;
    [SerializeField] private float gravity = -9.8f;
    [SerializeField] private float groundCheckDistance = 0.2f;
    [SerializeField] private LayerMask groundLayer;

    [Header("Rotation")]
    [SerializeField] private float rotationSharpness = 25f;

    [Header("References")]
    [SerializeField] private Transform cameraTransform;

    // Properties
    public Vector3 Velocity { get; set; }
    public Vector2 Input { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool SprintHeld { get; private set; }

    public AnimatorController Animator { get; private set; }
    public EntityStateMachine<Player> StateMachine { get; private set; }
    public CombatStateMachine CombatStateMachine { get; private set; }

    private CameraControllerCinemachine cameraController;
    private WeaponController weaponController;

    // ICombatHandler implementation
    public Vector3 AttackDirection
    {
        get
        {
            if (cameraController.LockedOn)
                return transform.forward;

            if (Input == Vector2.zero)
                return transform.forward;

            return GetCameraRelativeInput();
        }
    }

    public bool IsLockedOn => cameraController.LockedOn;

    public Attack.Context[] Context
    {
        get
        {
            var contexts = new System.Collections.Generic.List<Attack.Context>();

            if (IsLockedOn)
                contexts.Add(Attack.Context.LockedOn);

            if (IsGrounded())
                contexts.Add(Attack.Context.Grounded);
            else
                contexts.Add(Attack.Context.InAir);

            return contexts.ToArray();
        }
    }

    public Weapon CurrentWeapon => weaponController.currentWeapon;

    // ============================================================================
    // INITIALIZATION
    // ============================================================================

    private void Awake()
    {
        cameraController = FindFirstObjectByType<CameraControllerCinemachine>();
        Animator = GetComponent<AnimatorController>();
        weaponController = GetComponent<WeaponController>();
        CombatStateMachine = GetComponent<CombatStateMachine>();

        if (cameraTransform == null)
            cameraTransform = Camera.main.transform;

        CombatStateMachine.Initialize(this);
    }

    private void Start()
    {
        StateMachine = new EntityStateMachine<Player>(this);
        StateMachine.SwitchStates(new GroundedState());
    }

    // ============================================================================
    // UPDATE LOOP
    // ============================================================================

    private void Update()
    {
        ReadInput();
        StateMachine.currentState.HandleInput(this);
        StateMachine.currentState.Update(this);
    }

    private void ReadInput()
    {
        Input = new Vector2(
            UnityEngine.Input.GetAxisRaw("Horizontal"),
            UnityEngine.Input.GetAxisRaw("Vertical")
        );

        JumpPressed = UnityEngine.Input.GetKeyDown(KeyCode.Space);
        SprintHeld = UnityEngine.Input.GetKey(KeyCode.LeftControl);
    }

    // ============================================================================
    // CONTEXT QUERIES
    // ============================================================================

    public bool IsGrounded()
    {
        return Physics.Raycast(
            transform.position,
            Vector3.down,
            groundCheckDistance,
            groundLayer
        );
    }

    public Vector3 GetCameraRelativeInput()
    {
        Vector3 camForward = Vector3.ProjectOnPlane(
            cameraTransform.forward,
            Vector3.up
        ).normalized;

        Vector3 camRight = Vector3.ProjectOnPlane(
            cameraTransform.right,
            Vector3.up
        ).normalized;

        Vector3 direction = camForward * Input.y + camRight * Input.x;

        if (direction.sqrMagnitude > 1f)
            direction.Normalize();

        return direction;
    }

    // ============================================================================
    // MOVEMENT STATES
    // ============================================================================

    public class GroundedState : State<Player>
    {
        public override void Enter(Player p)
        {
            // Clamp vertical velocity to zero when entering grounded state
            if (p.Velocity.y < 0)
                p.Velocity = new Vector3(p.Velocity.x, 0, p.Velocity.z);
        }

        public override void HandleInput(Player p)
        {
            if (p.JumpPressed)
            {
                p.StateMachine.SwitchStates(new JumpState());
                return;
            }

            if (p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new GroundAttackingState());
                return;
            }

            if (p.cameraController.LockedOn)
            {
                p.StateMachine.SwitchStates(new LockOnState());
            }
        }

        public override void Update(Player p)
        {
            Vector3 moveDir = p.GetCameraRelativeInput();
            float speed = p.SprintHeld && moveDir.sqrMagnitude > 0
                ? p.sprintSpeed
                : p.walkSpeed;

            Vector3 desiredVelocity = moveDir * speed;
            Vector3 horizontal = new Vector3(p.Velocity.x, 0, p.Velocity.z);

            horizontal = Vector3.MoveTowards(
                horizontal,
                desiredVelocity,
                p.acceleration * Time.deltaTime
            );

            p.Velocity = new Vector3(horizontal.x, 0, horizontal.z);
            p.transform.position += p.Velocity * Time.deltaTime;

            UpdateRotation(p, horizontal);
            p.Animator.UpdateMovement(p.Velocity, p.strafingSpeed, p.walkSpeed, p.sprintSpeed);

            if (!p.IsGrounded())
                p.StateMachine.SwitchStates(new FallState());
        }

        public override void Exit(Player p) { }

        private void UpdateRotation(Player p, Vector3 horizontal)
        {
            if (horizontal.sqrMagnitude < 0.001f)
                return;

            Quaternion target = Quaternion.LookRotation(horizontal);
            p.transform.rotation = Quaternion.Slerp(
                p.transform.rotation,
                target,
                1f - Mathf.Exp(-p.rotationSharpness * Time.deltaTime)
            );
        }
    }

    public class JumpState : State<Player>
    {
        public override void Enter(Player p)
        {
            p.Velocity = new Vector3(p.Velocity.x, p.jumpForce, p.Velocity.z);
            p.Animator.TriggerJump();
        }

        public override void HandleInput(Player p)
        {
            if (p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new AirAttackingState());
            }
        }

        public override void Update(Player p)
        {
            ApplyAirMovement(p);
            ApplyGravity(p);
            p.transform.position += p.Velocity * Time.deltaTime;

            p.Animator.UpdateMovement(p.Velocity, p.strafingSpeed, p.walkSpeed, p.sprintSpeed);

            if (p.Velocity.y <= 0)
                p.StateMachine.SwitchStates(new FallState());
        }

        public override void Exit(Player p) { }

        private void ApplyAirMovement(Player p)
        {
            Vector3 moveDir = p.GetCameraRelativeInput();
            Vector3 horizontal = new Vector3(p.Velocity.x, 0, p.Velocity.z);

            horizontal = Vector3.MoveTowards(
                horizontal,
                moveDir * p.walkSpeed,
                p.acceleration * p.airControl * Time.deltaTime
            );

            p.Velocity = new Vector3(horizontal.x, p.Velocity.y, horizontal.z);
        }

        private void ApplyGravity(Player p)
        {
            p.Velocity += Vector3.up * p.gravity * Time.deltaTime;
        }
    }

    public class FallState : State<Player>
    {
        public override void Enter(Player p)
        {
            p.Animator.ResetTriggerJump();
        }

        public override void HandleInput(Player p)
        {
            if (p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new AirAttackingState());
            }
        }

        public override void Update(Player p)
        {
            ApplyAirMovement(p);
            ApplyGravity(p);
            p.transform.position += p.Velocity * Time.deltaTime;

            p.Animator.UpdateMovement(p.Velocity, p.strafingSpeed, p.walkSpeed, p.sprintSpeed);

            if (p.IsGrounded())
                p.StateMachine.SwitchStates(new GroundedState());
        }

        public override void Exit(Player p)
        {
            // Landing cleanup
            if (p.Velocity.y < 0)
                p.Velocity = new Vector3(p.Velocity.x, 0, p.Velocity.z);
        }

        private void ApplyAirMovement(Player p)
        {
            Vector3 moveDir = p.GetCameraRelativeInput();
            Vector3 horizontal = new Vector3(p.Velocity.x, 0, p.Velocity.z);

            horizontal = Vector3.MoveTowards(
                horizontal,
                moveDir * p.walkSpeed,
                p.acceleration * p.airControl * Time.deltaTime
            );

            p.Velocity = new Vector3(horizontal.x, p.Velocity.y, horizontal.z);
        }

        private void ApplyGravity(Player p)
        {
            p.Velocity += Vector3.up * p.gravity * Time.deltaTime;
        }
    }

    public class LockOnState : State<Player>
    {
        public override void Enter(Player p) { }

        public override void HandleInput(Player p)
        {
            if (p.JumpPressed)
            {
                p.StateMachine.SwitchStates(new JumpState());
                return;
            }

            if (p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new GroundAttackingState());
            }
        }

        public override void Update(Player p)
        {
            if (!p.cameraController.LockedOn)
            {
                p.StateMachine.SwitchStates(new GroundedState());
                return;
            }

            if (!p.IsGrounded())
            {
                p.StateMachine.SwitchStates(new FallState());
                return;
            }

            UpdateMovement(p);
            UpdateRotation(p);
            p.Animator.UpdateMovement(p.Velocity, p.strafingSpeed, p.walkSpeed, p.sprintSpeed);
        }

        public override void Exit(Player p)
        {
            p.Velocity = Vector3.zero;
        }

        private void UpdateMovement(Player p)
        {
            Transform enemy = p.cameraController.Enemy.Object;
            Vector3 toEnemy = enemy.position - p.transform.position;
            toEnemy.y = 0f;

            if (toEnemy.sqrMagnitude < 0.001f)
                return;

            Vector3 radial = toEnemy.normalized;
            Vector3 tangent = new Vector3(-radial.z, 0f, radial.x);

            Vector3 moveDir = p.GetCameraRelativeInput();
            float strafe = Vector3.Dot(moveDir, tangent);
            float inOut = Vector3.Dot(moveDir, -radial);

            Vector3 desiredVelocity = (tangent * strafe + radial * inOut) * p.strafingSpeed;
            Vector3 horizontal = new Vector3(p.Velocity.x, 0f, p.Velocity.z);

            horizontal = Vector3.MoveTowards(
                horizontal,
                desiredVelocity,
                p.acceleration * Time.deltaTime
            );

            p.Velocity = new Vector3(horizontal.x, p.Velocity.y, horizontal.z);
            p.transform.position += p.Velocity * Time.deltaTime;
        }

        private void UpdateRotation(Player p)
        {
            Vector3 toEnemy = (p.cameraController.Enemy.Object.position - p.transform.position).normalized;

            if (toEnemy.sqrMagnitude < 0.001f)
                return;

            Quaternion target = Quaternion.LookRotation(toEnemy);
            p.transform.rotation = Quaternion.Slerp(
                p.transform.rotation,
                target,
                1f - Mathf.Exp(-p.rotationSharpness * Time.deltaTime)
            );
        }
    }

    /// <summary>Ground-based attack state with movement during active frames.</summary>
    public class GroundAttackingState : State<Player>
    {
        private Attack currentAttack;
        private Vector3 attackDirection;
        private float attackTimer;
        private Vector3 attackStart;
        private Vector3 attackEnd;

        public override void Enter(Player p)
        {
            InitializeAttack(p);
        }

        public override void HandleInput(Player p)
        {
            // Exit attack if it's finished
            if (!p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new GroundedState());
            }
        }

        public override void Update(Player p)
        {
            if (currentAttack == null)
                return;

            int activeEnd = currentAttack.StartUpFrames + currentAttack.ActiveFrames;

            // Re-initialize on transition for smooth movement
            if (p.CombatStateMachine.IsTransitioning)
            {
                InitializeAttack(p);
            }

            attackEnd = CalculateMovementDestination(p);

            // Only move during active frames
            if (p.CombatStateMachine.CurrentAttackTick <= activeEnd)
            {
                MovePlayerDuringAttack(p);
                UpdateRotation(p);
            }
        }

        public override void Exit(Player p) { }

        private void InitializeAttack(Player p)
        {
            currentAttack = p.CombatStateMachine.CurrentAttack;

            attackDirection = p.cameraController.LockedOn
                ? p.transform.forward
                : p.GetCameraRelativeInput();

            if (attackDirection == Vector3.zero)
                attackDirection = p.transform.forward;

            attackTimer = 0;
            attackStart = p.transform.position;
            attackEnd = CalculateMovementDestination(p);
        }

        private void MovePlayerDuringAttack(Player p)
        {
            if (currentAttack == null)
                return;

            attackTimer += Time.deltaTime;
            float normalizedTime = Mathf.Clamp01(attackTimer / currentAttack.attackSpeed);
            float easedTime = currentAttack.lungeCurve.Evaluate(normalizedTime);

            p.transform.position = Vector3.Lerp(attackStart, attackEnd, easedTime);
        }

        private Vector3 CalculateMovementDestination(Player p)
        {
            if (currentAttack == null)
                return p.transform.position;

            Vector3 destination = attackStart + attackDirection * currentAttack.forwardMovementImpulse;
            Vector3 movementVector = destination - attackStart;
            float maxDistance = movementVector.magnitude;

            // Check for collisions along movement path
            if (Physics.Raycast(
                attackStart,
                movementVector.normalized,
                out RaycastHit hit,
                maxDistance))
            {
                const float COLLISION_OFFSET = 0.1f;
                float clampedDistance = Mathf.Clamp01((hit.distance - COLLISION_OFFSET) / maxDistance);
                return attackStart + clampedDistance * movementVector;
            }

            return destination;
        }

        private void UpdateRotation(Player p)
        {
            if (attackDirection.sqrMagnitude < 0.001f)
                return;

            Quaternion target = Quaternion.LookRotation(attackDirection);
            p.transform.rotation = Quaternion.Slerp(
                p.transform.rotation,
                target,
                1f - Mathf.Exp(-p.rotationSharpness * Time.deltaTime)
            );
        }
    }

    /// <summary>Air-based attack state for aerial combos (like DMC air juggle combos).</summary>
    public class AirAttackingState : State<Player>
    {
        private Attack currentAttack;
        private Vector3 attackDirection;
        private float attackTimer;
        private Vector3 attackStart;
        private Vector3 attackEnd;
        private Vector3 preservedVerticalVelocity;

        public override void Enter(Player p)
        {
            // Preserve existing vertical velocity to allow juggle momentum
            preservedVerticalVelocity = new Vector3(0, p.Velocity.y, 0);
            InitializeAttack(p);
        }

        public override void HandleInput(Player p)
        {
            // Allow jump cancels from air attacks
            if (p.JumpPressed)
            {
                p.CombatStateMachine.RequestCancelAttack();
                p.StateMachine.SwitchStates(new JumpState());
                return;
            }

            // Exit attack if it's finished
            if (!p.CombatStateMachine.IsAttacking)
            {
                p.StateMachine.SwitchStates(new FallState());
            }
        }

        public override void Update(Player p)
        {
            if (currentAttack == null)
                return;

            int activeEnd = currentAttack.StartUpFrames + currentAttack.ActiveFrames;

            // Re-initialize on transition
            if (p.CombatStateMachine.IsTransitioning)
            {
                InitializeAttack(p);
            }

            attackEnd = CalculateMovementDestination(p);

            // Apply gravity and movement during attack
            ApplyGravity(p);

            if (p.CombatStateMachine.CurrentAttackTick <= activeEnd)
            {
                MovePlayerDuringAttack(p);
                UpdateRotation(p);
            }

            p.transform.position += p.Velocity * Time.deltaTime;
        }

        public override void Exit(Player p) { }

        private void InitializeAttack(Player p)
        {
            currentAttack = p.CombatStateMachine.CurrentAttack;

            attackDirection = p.cameraController.LockedOn
                ? p.transform.forward
                : p.GetCameraRelativeInput();

            if (attackDirection == Vector3.zero)
                attackDirection = p.transform.forward;

            attackTimer = 0;
            attackStart = p.transform.position;
            attackEnd = CalculateMovementDestination(p);
        }

        private void MovePlayerDuringAttack(Player p)
        {
            if (currentAttack == null)
                return;

            attackTimer += Time.deltaTime;
            float normalizedTime = Mathf.Clamp01(attackTimer / currentAttack.attackSpeed);
            float easedTime = currentAttack.lungeCurve.Evaluate(normalizedTime);

            Vector3 horizontalMovement = Vector3.Lerp(
                Vector3.ProjectOnPlane(attackStart, Vector3.up),
                Vector3.ProjectOnPlane(attackEnd, Vector3.up),
                easedTime
            );

            p.Velocity = horizontalMovement - Vector3.ProjectOnPlane(p.transform.position, Vector3.up);
        }

        private void ApplyGravity(Player p)
        {
            p.Velocity += Vector3.up * p.gravity * Time.deltaTime;
        }

        private Vector3 CalculateMovementDestination(Player p)
        {
            if (currentAttack == null)
                return p.transform.position;

            Vector3 horizontalPos = Vector3.ProjectOnPlane(p.transform.position, Vector3.up);
            Vector3 destination = horizontalPos + attackDirection * currentAttack.forwardMovementImpulse;
            Vector3 movementVector = destination - horizontalPos;
            float maxDistance = movementVector.magnitude;

            // Check for collisions
            if (Physics.Raycast(
                horizontalPos,
                movementVector.normalized,
                out RaycastHit hit,
                maxDistance))
            {
                const float COLLISION_OFFSET = 0.1f;
                float clampedDistance = Mathf.Clamp01((hit.distance - COLLISION_OFFSET) / maxDistance);
                destination = horizontalPos + clampedDistance * movementVector;
            }

            // Preserve vertical position (gravity is applied separately)
            return new Vector3(destination.x, p.transform.position.y, destination.z);
        }

        private void UpdateRotation(Player p)
        {
            if (attackDirection.sqrMagnitude < 0.001f)
                return;

            Quaternion target = Quaternion.LookRotation(attackDirection);
            p.transform.rotation = Quaternion.Slerp(
                p.transform.rotation,
                target,
                1f - Mathf.Exp(-p.rotationSharpness * Time.deltaTime)
            );
        }
    }
}
