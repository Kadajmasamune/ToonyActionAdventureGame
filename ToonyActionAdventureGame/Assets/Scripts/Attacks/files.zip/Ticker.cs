using System;
using UnityEngine;

/// <summary>
/// Frame-perfect tick generator at 60 FPS.
/// All combat logic should subscribe to OnTick and use CurrentTick for deterministic timing.
/// </summary>
public class Ticker : MonoBehaviour
{
    private const float TICK_RATE = 1f / 60f; // 60 FPS

    private float accumulator;
    private int currentTick;

    public static event Action OnTick;
    public int CurrentTick => currentTick;
    public static Ticker instance { get; private set; }

    private void Start()
    {
        if (instance != null && instance != this)
        {
            Debug.LogWarning("Multiple Ticker instances detected. Destroying duplicate.");
            Destroy(gameObject);
            return;
        }

        instance = this;
        accumulator = 0f;
        currentTick = 0;
    }

    private void Update()
    {
        accumulator += Time.deltaTime;

        while (ShouldTick())
        {
            accumulator -= TICK_RATE;
            currentTick++;
            OnTick?.Invoke();
        }
    }

    private bool ShouldTick()
    {
        return accumulator >= TICK_RATE;
    }
}
