using UnityEngine;

/// <summary>
/// ScriptableObject defining a single attack with all its properties.
/// Inherits frame data (startup, active, recovery) and adds combat-specific fields.
/// </summary>
[CreateAssetMenu(fileName = "New Attack", menuName = "Combat/Attack")]
public class Attack : FrameData
{
    [System.Flags]
    public enum Context
    {
        /// <summary>Attack only available while locked onto an enemy.</summary>
        LockedOn = 1,

        /// <summary>Attack only available while on the ground.</summary>
        Grounded = 2,

        /// <summary>Attack available while in the air (jumping, falling, or airborne from knockback).</summary>
        InAir = 4,
    }

    // ============================================================================
    // DAMAGE & IMPACT
    // ============================================================================

    [Header("Damage")]
    [SerializeField] private float damage = 10f;
    public float Damage => damage;

    [SerializeField] private float upwardLaunchImpulse = 0f;
    public float upwardLaunchImpulse => upwardLaunchImpulse;

    [SerializeField] private float knockBackInflicted = 0f;
    public float knockBackInflicted => knockBackInflicted;

    [SerializeField] private float hitStunInflicted = 0f;
    public float hitStunInflicted => hitStunInflicted;

    [SerializeField] private float hitStopDuration = 0.1f;
    public float hitStopDuration => hitStopDuration;

    [SerializeField] private float cameraShakeIntensity = 0f;
    public float cameraShakeIntensity => cameraShakeIntensity;

    // ============================================================================
    // MOVEMENT
    // ============================================================================

    [Header("Movement")]
    [SerializeField] private float forwardMovementImpulse = 0f;
    public float forwardMovementImpulse => forwardMovementImpulse;

    [SerializeField] private float attackSpeed = 0.5f; // Duration of lunge/knockback
    public float attackSpeed => attackSpeed;

    [SerializeField] private AnimationCurve lungeCurve = AnimationCurve.Linear(0, 0, 1, 1);
    public AnimationCurve lungeCurve => lungeCurve;

    // ============================================================================
    // CONTEXT & TRANSITIONS
    // ============================================================================

    [Header("Attack Context")]
    [SerializeField] private Context[] contextRequired = new[] { Context.Grounded };
    public Context[] contextRequired => contextRequired;

    [SerializeField] private Attack[] allowedAttackTransitions = new Attack[0];
    public Attack[] AllowedAttackTransitions => allowedAttackTransitions;

    // ============================================================================
    // ANIMATION
    // ============================================================================

    [Header("Animation")]
    [SerializeField] private AnimationClip animationClip;
    public AnimationClip clip => animationClip;

    [SerializeField]
    [Tooltip("Attack Index must match the index within the Animator Controller")]
    private int attackIndexLayer = 0;
    public int AttackIndexLayer => attackIndexLayer;

    // ============================================================================
    // INPUT
    // ============================================================================

    [Header("Input")]
    [SerializeField] private InputBufferer.AttackInput requiredInput = InputBufferer.AttackInput.Light;
    public InputBufferer.AttackInput RequiredInput => requiredInput;

    // ============================================================================
    // FRAME WINDOWS
    // ============================================================================

    [Header("Frame Windows")]
    public new FrameWindows[] FrameWindows;
}
