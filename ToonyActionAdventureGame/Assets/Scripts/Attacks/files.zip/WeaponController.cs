using UnityEngine;

/// <summary>
/// Manages weapon inventory and switching.
/// Provides access to the currently equipped weapon for the combat system.
/// </summary>
public class WeaponController : MonoBehaviour
{
    [SerializeField] private LayerMask weaponLayer;
    private Weapon[] weapons;
    private int currentWeaponIndex = 0;

    public Weapon currentWeapon { get; private set; }

    private void Start()
    {
        InitializeWeapons();
    }

    private void Update()
    {
        if (CanSwitchWeapon())
        {
            SwitchToNextWeapon();
        }
    }

    private void InitializeWeapons()
    {
        weapons = GetComponentsInChildren<Weapon>();

        if (weapons.Length == 0)
        {
            Debug.LogError($"No weapons found on {gameObject.name}");
            return;
        }

        ValidateWeaponLayers();
        currentWeapon = weapons[0];
    }

    private void ValidateWeaponLayers()
    {
        foreach (Weapon weapon in weapons)
        {
            int weaponLayerBit = 1 << weapon.gameObject.layer;
            bool isInWeaponLayer = (weaponLayer.value & weaponLayerBit) != 0;

            if (!isInWeaponLayer)
            {
                Debug.LogError(
                    $"Weapon '{weapon.gameObject.name}' is not in the weapon layer. " +
                    $"Current layer: {LayerMask.LayerToName(weapon.gameObject.layer)}"
                );
            }
        }
    }

    private bool CanSwitchWeapon()
    {
        return UnityEngine.Input.GetKeyDown(KeyCode.E);
    }

    private void SwitchToNextWeapon()
    {
        if (weapons.Length <= 1)
            return;

        int startIndex = currentWeaponIndex;

        do
        {
            currentWeaponIndex++;
            if (currentWeaponIndex >= weapons.Length)
                currentWeaponIndex = 0;

        } while (weapons[currentWeaponIndex] == null && currentWeaponIndex != startIndex);

        currentWeapon = weapons[currentWeaponIndex];
    }
}
