using UnityEngine;

/// <summary>
/// Base class for frame data containing startup, active, and recovery frames.
/// Used by Attack and other actions that need frame-precise timing.
/// </summary>
public abstract class FrameData : ScriptableObject
{
    [Header("Frame Windows")]
    [Tooltip("Frames before attack becomes active (cannot combo during this)")]
    public int StartUpFrames;

    [Tooltip("Frames where hitbox is active")]
    public int ActiveFrames;

    [Tooltip("Frames after active (can combo during this)")]
    public int RecoveryFrames;

    public enum WindowType
    {
        /// <summary>Can transition to other attacks during this window.</summary>
        Interrupt,
        
        /// <summary>Character is invulnerable during this window.</summary>
        Invulnerability,
        
        /// <summary>No special window property.</summary>
        None
    }

    [System.Serializable]
    public struct FrameWindows
    {
        public int startFrame;
        public int endFrame;
        public WindowType windowType;
    }

    /// <summary>Total duration of this action in frames.</summary>
    public int TotalFrames => StartUpFrames + ActiveFrames + RecoveryFrames;
}
