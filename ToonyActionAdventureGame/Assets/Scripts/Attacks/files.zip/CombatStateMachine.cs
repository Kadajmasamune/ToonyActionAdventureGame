using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using static FrameData;
using static InputBufferer;

/// <summary>
/// Core attack state machine handling: attack selection, transitions, hit detection, and frame-perfect timing.
/// Works in tandem with Ticker for deterministic frame-based combat.
/// </summary>
public class CombatStateMachine : MonoBehaviour
{
    [Header("Attack Configuration")]
    [SerializeField] private Attack[] possibleAttacks;
    
    [Header("References")]
    [SerializeField] private InputBufferer bufferer;
    private AnimatorController animator;
    private IWeapon weaponHandler;
    private ICombatHandler handler;

    // Attack State
    public Attack CurrentAttack { get; private set; }
    public bool IsAttacking { get; private set; }
    public bool IsTransitioning { get; private set; }
    public int CurrentAttackTick { get; private set; }

    // Internal State
    private int attackStartTick;
    private bool hasChainedInWindow;
    private bool isTryingToCancel;
    private HashSet<Collider> hitTargets = new();
    private Dictionary<Collider, ImpactData> impacts = new();
    private List<Collider> finishedImpacts = new();

    // Cached properties
    private IReadOnlyList<Collider> TargetsHit => weaponHandler.Targets;
    private bool ShouldLaunchTarget => 
        CurrentAttack != null && 
        CurrentAttack.upwardLaunchImpulse > 0 && 
        CurrentAttack.knockBackInflicted <= 0;

    /// <summary>Impact tracking for knockback and launch effects.</summary>
    private class ImpactData
    {
        public Vector3 StartPosition;
        public Vector3 EndPosition;
        public float ElapsedTime;
        public float Duration;
        public AnimationCurve Curve;
    }

    // ============================================================================
    // INITIALIZATION
    // ============================================================================

    public void Initialize(ICombatHandler handler)
    {
        this.handler = handler;
    }

    public void Initialize(IWeapon weaponHandler)
    {
        this.weaponHandler = weaponHandler;
    }

    private void Start()
    {
        bufferer = GetComponent<InputBufferer>();
        animator = GetComponent<AnimatorController>();
        
        if (bufferer == null)
            Debug.LogError("InputBufferer not found on " + gameObject.name);
        if (animator == null)
            Debug.LogError("AnimatorController not found on " + gameObject.name);
    }

    private void OnEnable()
    {
        Ticker.OnTick += OnTick;
    }

    private void OnDisable()
    {
        Ticker.OnTick -= OnTick;
    }

    // ============================================================================
    // TICK LOOP
    // ============================================================================

    private void OnTick()
    {
        UpdateActiveImpacts();

        if (!IsAttacking && !IsTransitioning)
        {
            TryStartAttack();
            return;
        }

        UpdateAttack();
    }

    // ============================================================================
    // ATTACK INITIATION
    // ============================================================================

    private void TryStartAttack()
    {
        if (!bufferer.HasInput)
            return;

        Attack attack = GetAttackFromInput(bufferer.ConsumeInput());
        if (attack != null && CanStartAttack(attack))
        {
            StartAttack(attack);
        }
    }

    private Attack GetAttackFromInput(AttackInput input)
    {
        return possibleAttacks.FirstOrDefault(attack => attack.RequiredInput == input);
    }

    private bool CanStartAttack(Attack attack)
    {
        if (attack == null)
            return false;

        // Check if current context matches required attack context
        if (attack.contextRequired.Length > 0)
        {
            return handler.Context.Any(ctx => attack.contextRequired.Contains(ctx));
        }

        return true;
    }

    private void StartAttack(Attack attack)
    {
        CurrentAttack = attack;
        IsAttacking = true;
        IsTransitioning = false;
        hasChainedInWindow = false;
        isTryingToCancel = false;

        hitTargets.Clear();
        weaponHandler.DisableHitbox();
        weaponHandler.ClearTargets();

        attackStartTick = Ticker.instance.CurrentTick;

        PlayAttackAnimation(attack, isTransition: false);
    }

    // ============================================================================
    // ATTACK UPDATE
    // ============================================================================

    private void UpdateAttack()
    {
        int tick = Ticker.instance.CurrentTick - attackStartTick;
        CurrentAttackTick = tick;
        
        if (IsTransitioning)
            IsTransitioning = false;

        int totalFrames = CurrentAttack.StartUpFrames + CurrentAttack.ActiveFrames + CurrentAttack.RecoveryFrames;

        UpdateWeaponState(tick);
        ApplyAttackEffects(CurrentAttack);
        HandleAttackWindowEvents(tick);

        if (tick >= totalFrames)
        {
            EndAttack();
        }
    }

    private void HandleAttackWindowEvents(int tick)
    {
        WindowType currentWindow = GetCurrentWindow(tick, CurrentAttack);

        // Only allow one chain per window
        if (currentWindow != WindowType.Interrupt)
        {
            hasChainedInWindow = false;
        }
        else
        {
            // Try to chain into next attack
            Attack nextAttack = GetNextAttack(CurrentAttack);
            if (nextAttack != null)
            {
                hasChainedInWindow = true;
                TransitionAttack(nextAttack);
                return;
            }

            // Try to cancel if player requested it
            if (isTryingToCancel)
            {
                CancelAttack();
            }
        }

        // Apply invulnerability during specific windows
        if (currentWindow == WindowType.Invulnerability)
        {
            // TODO: Apply invulnerability to player
        }
    }

    // ============================================================================
    // WEAPON & HITBOX MANAGEMENT
    // ============================================================================

    private void UpdateWeaponState(int tick)
    {
        int activeStart = CurrentAttack.StartUpFrames;
        int activeEnd = activeStart + CurrentAttack.ActiveFrames;

        if (tick >= activeStart && tick <= activeEnd)
        {
            weaponHandler.EnableHitbox();
        }
        else
        {
            weaponHandler.DisableHitbox();
        }
    }

    private void ApplyAttackEffects(Attack attack)
    {
        foreach (Collider target in TargetsHit)
        {
            // Only apply effects once per target per attack
            if (hitTargets.Contains(target))
                continue;

            hitTargets.Add(target);
            ApplyDamage(target, attack);
            ApplyImpact(target, attack);
            ApplyHitStop(attack);
        }
    }

    private void ApplyDamage(Collider target, Attack attack)
    {
        Health healthComponent = target.GetComponent<Health>();
        if (healthComponent != null)
        {
            healthComponent.TakeDamage(attack.Damage);
        }
    }

    private void ApplyImpact(Collider target, Attack attack)
    {
        Vector3 targetPos = target.transform.position;
        Vector3 endPos;

        if (ShouldLaunchTarget)
        {
            // Launch upward
            endPos = targetPos + Vector3.up * attack.upwardLaunchImpulse;
        }
        else
        {
            // Knockback in direction away from attacker
            Vector3 knockbackDirection = (targetPos - transform.position).normalized;
            endPos = targetPos + knockbackDirection * attack.knockBackInflicted;
        }

        impacts[target] = new ImpactData
        {
            StartPosition = targetPos,
            EndPosition = endPos,
            ElapsedTime = 0,
            Duration = attack.attackSpeed,
            Curve = attack.lungeCurve
        };
    }

    private void ApplyHitStop(Attack attack)
    {
        StartCoroutine(HitStopCoroutine(attack.hitStopDuration));
    }

    private IEnumerator HitStopCoroutine(float duration)
    {
        Time.timeScale = 0f;
        yield return new WaitForSecondsRealtime(duration);
        Time.timeScale = 1f;
    }

    // ============================================================================
    // ATTACK CHAINING & CANCELLATION
    // ============================================================================

    private Attack GetNextAttack(Attack currentAttack)
    {
        if (hasChainedInWindow || currentAttack.AllowedAttackTransitions.Length == 0)
            return null;

        AttackInput input = bufferer.PeekInput();
        return currentAttack.AllowedAttackTransitions.FirstOrDefault(
            transition => transition.RequiredInput == input
        );
    }

    private void TransitionAttack(Attack nextAttack)
    {
        CurrentAttack = nextAttack;
        attackStartTick = Ticker.instance.CurrentTick;
        IsAttacking = true;
        IsTransitioning = true;
        hasChainedInWindow = false;

        hitTargets.Clear();
        weaponHandler.ClearTargets();
        bufferer.ConsumeInput();

        PlayAttackAnimation(nextAttack, isTransition: true);
    }

    public void RequestCancelAttack()
    {
        isTryingToCancel = true;
    }

    private void CancelAttack()
    {
        // Cancel is allowed during interrupt windows
        // This allows transitions to other actions (jump, parry, etc)
        EndAttack();
    }

    private void EndAttack()
    {
        if (CurrentAttack != null)
        {
            animator.StopAttack(Animator.StringToHash(CurrentAttack.clip.name));
        }

        CurrentAttack = null;
        IsAttacking = false;
        IsTransitioning = false;
        hasChainedInWindow = false;
        isTryingToCancel = false;
        attackStartTick = 0;

        weaponHandler.DisableHitbox();
        weaponHandler.ClearTargets();
        hitTargets.Clear();
    }

    // ============================================================================
    // IMPACT & KNOCKBACK
    // ============================================================================

    private void UpdateActiveImpacts()
    {
        finishedImpacts.Clear();

        foreach (var kvp in impacts)
        {
            UpdateSingleImpact(kvp.Key, kvp.Value);

            if (kvp.Value.ElapsedTime >= kvp.Value.Duration)
            {
                finishedImpacts.Add(kvp.Key);
            }
        }

        foreach (Collider target in finishedImpacts)
        {
            impacts.Remove(target);
        }
    }

    private void UpdateSingleImpact(Collider target, ImpactData data)
    {
        if (target == null)
            return;

        data.ElapsedTime += Time.deltaTime;

        float normalizedTime = Mathf.Clamp01(data.ElapsedTime / data.Duration);
        float easedTime = data.Curve.Evaluate(normalizedTime);

        target.transform.position = Vector3.Lerp(
            data.StartPosition,
            data.EndPosition,
            easedTime
        );
    }

    // ============================================================================
    // FRAME WINDOW QUERIES
    // ============================================================================

    public WindowType GetCurrentWindow(int tick, Attack attack)
    {
        if (attack == null || attack.FrameWindows.Length == 0)
            return WindowType.None;

        // Check interrupt windows first (higher priority)
        foreach (var window in attack.FrameWindows)
        {
            if (window.windowType == WindowType.Interrupt &&
                IsTickInWindow(tick, window))
            {
                return WindowType.Interrupt;
            }
        }

        // Then check invulnerability windows
        foreach (var window in attack.FrameWindows)
        {
            if (window.windowType == WindowType.Invulnerability &&
                IsTickInWindow(tick, window))
            {
                return WindowType.Invulnerability;
            }
        }

        return WindowType.None;
    }

    private bool IsTickInWindow(int tick, FrameData.FrameWindows window)
    {
        return tick >= window.startFrame && tick <= window.endFrame;
    }

    // ============================================================================
    // ANIMATION
    // ============================================================================

    private void PlayAttackAnimation(Attack attack, bool isTransition)
    {
        int hash = Animator.StringToHash(attack.clip.name);
        animator.PlayAttack(hash, attack.AttackIndexLayer, isTransition);
    }
}
