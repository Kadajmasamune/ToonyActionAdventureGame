using UnityEngine;

/// <summary>
/// Frame-perfect input buffering for attack inputs.
/// Stores the most recent input and expires it after a configurable window.
/// Works in sync with Ticker for deterministic input handling.
/// </summary>
public class InputBufferer : MonoBehaviour
{
    public enum AttackInput { Light, Heavy, None }

    [Header("Buffer Settings")]
    [SerializeField] private int inputBufferWindow = 10; // ticks

    private AttackInput bufferedInput = AttackInput.None;
    private int bufferedTick = -1;
    private Ticker ticker;

    public bool HasInput { get; private set; }

    private void Start()
    {
        ticker = FindFirstObjectByType<Ticker>();

        if (ticker == null)
            Debug.LogError("Ticker not found in scene");
    }

    private void Update()
    {
        ReadInput();
        ExpireInput();
    }

    private void ReadInput()
    {
        // Light attack: Mouse0
        if (UnityEngine.Input.GetMouseButtonDown(0))
        {
            BufferInput(AttackInput.Light);
        }
        // Heavy attack: Mouse1
        else if (UnityEngine.Input.GetMouseButtonDown(1))
        {
            BufferInput(AttackInput.Heavy);
        }
    }

    private void BufferInput(AttackInput input)
    {
        bufferedInput = input;
        bufferedTick = ticker.CurrentTick;
        HasInput = true;
    }

    private void ExpireInput()
    {
        if (!HasInput)
            return;

        if (ticker.CurrentTick - bufferedTick > inputBufferWindow)
        {
            HasInput = false;
            bufferedInput = AttackInput.None;
        }
    }

    /// <summary>Get input without consuming it.</summary>
    public AttackInput PeekInput()
    {
        return HasInput ? bufferedInput : AttackInput.None;
    }

    /// <summary>Get input and mark it as consumed.</summary>
    public AttackInput ConsumeInput()
    {
        if (!HasInput)
            return AttackInput.None;

        AttackInput input = bufferedInput;
        HasInput = false;
        bufferedInput = AttackInput.None;
        return input;
    }
}
