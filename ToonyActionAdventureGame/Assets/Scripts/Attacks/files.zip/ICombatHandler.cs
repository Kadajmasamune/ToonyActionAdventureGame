using UnityEngine;

/// <summary>
/// Interface that combat-capable entities (Player, AI) must implement.
/// Provides CombatStateMachine with context-aware information for attack selection.
/// </summary>
public interface ICombatHandler
{
    /// <summary>The attack direction based on player input or AI decision.</summary>
    Vector3 AttackDirection { get; }

    /// <summary>Whether the handler is locked onto an enemy.</summary>
    bool IsLockedOn { get; }

    /// <summary>Attack contexts (LockedOn, Grounded, InAir) that affect attack selection.</summary>
    Attack.Context[] Context { get; }

    /// <summary>Currently equipped weapon.</summary>
    Weapon CurrentWeapon { get; }
}
